package Problem_3;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import Problem_3.Problem3Class;

public class Problem3ClassTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIsSorted() {
		
		Problem3Class p3c=new Problem3Class();
		
		int[] tc01numbers={0,0,0,0}; //all duplicate values
		int[] tc02numbers={0,1,2,3}; //positive sorted values with 0
		int[] tc03numbers={4,0,3,3}; // positive unsorted values with 0 and duplicate values
		int[] tc04numbers={-3,-2,-1,0}; // negative sorted values with 0
		int[] tc05numbers={-3,-310,0,0}; // negative unsorted values with 0 and duplicate values
		int[] tc06numbers={-1,0,1,2}; // mix sorted values
		int[] tc07numbers={-1,-455,422,56}; // mix sorted values
		int[] tc08numbers={2};//single valuue array
		int[] tc09numbers={};//empty array
		
		
		Problem3Class tc01=new Problem3Class();
		tc01.isSorted(tc01numbers);
		assertEquals(true,tc01.isSorted(tc01numbers));
		
		
		Problem3Class tc02=new Problem3Class();
		tc02.isSorted(tc02numbers);
		assertEquals(true,tc02.isSorted(tc02numbers));
		
		Problem3Class tc03=new Problem3Class();
		tc03.isSorted(tc03numbers);
		assertEquals(false,tc03.isSorted(tc03numbers));
		
		Problem3Class tc04=new Problem3Class();
		tc04.isSorted(tc04numbers);
		assertEquals(true,tc04.isSorted(tc04numbers));
		
		Problem3Class tc05=new Problem3Class();
		tc05.isSorted(tc05numbers);
		assertEquals(false,tc05.isSorted(tc05numbers));
		

		Problem3Class tc06=new Problem3Class();
		tc06.isSorted(tc06numbers);
		assertEquals(true,tc06.isSorted(tc06numbers));
		
		Problem3Class tc07=new Problem3Class();
		tc07.isSorted(tc06numbers);
		assertEquals(false,tc07.isSorted(tc07numbers));
		
		Problem3Class tc08=new Problem3Class();
		tc08.isSorted(tc08numbers);
		assertEquals(true,tc08.isSorted(tc08numbers));
		
		Problem3Class tc09=new Problem3Class();
		tc07.isSorted(tc09numbers);
		assertEquals(false,tc09.isSorted(tc09numbers));
		
	}

}
