package Problem_3;

import Problem_3.Problem3Class;

public class Problem3Main {

	public static void main(String[] args) {
		Problem3Class p3c = new Problem3Class();
		boolean SortCheck;
		int[] numbers={1,1,2,3};
		SortCheck=p3c.isSorted(numbers);
		System.out.println("Sorted:"+SortCheck);

	}

}
