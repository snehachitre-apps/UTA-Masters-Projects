package Problem_3;

public class Problem3Class {
	public boolean isSorted (int[] nums) {
		// this method determines if an integer array of
		// any length is sorted in an ascending manner
		boolean sorted=nums.length > 0;
		
			
		for (int i = nums.length-1; i > 0  & sorted ; i--)
			if (((nums[i] - nums[i-1])<0))
			
				sorted=false;

		
		return sorted;
	}
}