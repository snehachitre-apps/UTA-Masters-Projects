package Problem_2;

public class Problem2Main {

	public static void main(String[] args) {
		
		Problem2Class p2c = new Problem2Class();
		int ResCount;
		int[] numbers={0,0,0,0};
		              
		ResCount=p2c.numPos(numbers);
		System.out.println("Count:"+ResCount);
	}

}

//