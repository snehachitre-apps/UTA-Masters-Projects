package Problem_2;

public class Problem2Class {
	public int numPos (int[] nums) {
		int Count = 0;
		for (int i = nums.length-1; i >= 0; i--)
			if (nums[i] > 0)
				Count++;
		return Count;
	}
}
