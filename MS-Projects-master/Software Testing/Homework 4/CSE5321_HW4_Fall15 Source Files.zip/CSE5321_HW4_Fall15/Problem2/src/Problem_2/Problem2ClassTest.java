package Problem_2;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class Problem2ClassTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
	
		int[] tc01numbers={-3,-2,-1,0}; // count zero
		int[] tc02numbers={-2,-1,0,1}; //position last, count 1
		int[] tc03numbers={1,0,-1,-2}; //position first, count 1
		int[] tc04numbers={-4,2,3,0}; //position middle, count multiple
		int[] tc05numbers={};//empty array
		
		Problem2Class tc01=new Problem2Class();
		tc01.numPos(tc01numbers);
		assertEquals(0,tc01.numPos(tc01numbers));
		
		Problem2Class tc02=new Problem2Class();
		tc02.numPos(tc02numbers);
		assertEquals(1,tc02.numPos(tc02numbers));
		
		
		Problem2Class tc03=new Problem2Class();
		tc03.numPos(tc03numbers);
		assertEquals(1,tc03.numPos(tc03numbers));
		
		Problem2Class tc04=new Problem2Class();
		tc04.numPos(tc04numbers);
		assertEquals(2,tc04.numPos(tc04numbers));
		
		
		Problem2Class tc05=new Problem2Class();
		tc05.numPos(tc05numbers);
		assertEquals(0,tc05.numPos(tc05numbers));
	}

}
