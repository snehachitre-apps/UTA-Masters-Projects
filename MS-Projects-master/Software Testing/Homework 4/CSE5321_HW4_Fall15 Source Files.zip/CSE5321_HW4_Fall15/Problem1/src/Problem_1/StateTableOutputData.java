package Problem_1;
public class StateTableOutputData {
	
private int x=0,y=0, v1=0,v2=0;

public StateTableOutputData (int x, int y,int v1,int v2) 
{
	this.x=x;
	this.y=y;
	this.v1=v1;
	this.v2=v2;
	
}

	public int getV1() 
	{
		return v1;
	}

	public int getV2() 
	{
		return v2;
	}

	public int getX()
	{
		return x;
	}

	public int getY()
	{
		return y;
	}

	public void setV1(int v1)
	{
		this.v1 = v1;
	}

	public void setV2(int v2) 
	{
		this.v2 = v2;
	}

	public void setX(int x)
	{	
		this.x = x;
	}

	public void setY(int y)
	{
		this.y = y;
	}

}
