package Problem_1;

public class StateTableClass {
	
	
	public void nextState (int v1,int v2, boolean a, StateTableOutputData outputs)
		{
			
			switch (v1*2 + v2){
			
			case 0: if (a)
			{
				outputs.setX(1);
				outputs.setY(2);
				outputs.setV1(0);
				outputs.setV2(1);
				
				System.out.println("State: S1");
					
			}
			else
			{
				outputs.setX(2);
				outputs.setY(1);
				outputs.setV1(0);
				outputs.setV2(0);
	
				System.out.println("State: S0");
			} 
			break;
			case 1: if (a)
			{
				outputs.setX(2);
				outputs.setY(2);
				outputs.setV1(1);
				outputs.setV2(0);
				
				System.out.println("State: S2");
			}
			else
			{
				outputs.setX(2);
				outputs.setY(1);
				outputs.setV1(0);
				outputs.setV2(1);
				
				System.out.println("State: S1");
			} 
			break;
			case 2: if (a)
			{
				outputs.setX(3);
				outputs.setY(2);
				outputs.setV1(1);
				outputs.setV2(1);
					
				System.out.println("State: S3");
			}
			else
			{
				outputs.setX(3);
				outputs.setY(1);
				outputs.setV1(1);
				outputs.setV2(0);
				
				System.out.println("State: S2");
			}
			break;
			case 3: if (a)
			{
				outputs.setX(3);
				outputs.setY(0);
				outputs.setV1(0);
				outputs.setV2(1);
					
				System.out.println("State: S1");
			}
			else
			{
				outputs.setX(4);
				outputs.setY(3);
				outputs.setV1(1);
				outputs.setV2(1);
				
				System.out.println("State: S3");
			} 
			break;
			
			default: 
				
				System.out.println("State: Start State");break;
				
		}

	}
}