package Problem_1;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class StateTableClassTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testNextstate() {
		StateTableOutputData op= new StateTableOutputData(0,0,0,0);
		
		StateTableClass tc01=new StateTableClass();
		tc01.nextState(-1,-1,false,op);
		assertEquals(0,op.getX());
		assertEquals(0,op.getY());
		assertEquals(0,op.getV1());
		assertEquals(0,op.getV2());
		
		StateTableClass tc02=new StateTableClass();
		tc02.nextState(0,0,true,op);
		assertEquals(1,op.getX());
		assertEquals(2,op.getY());
		assertEquals(0,op.getV1());
		assertEquals(1,op.getV2());

		StateTableClass tc03=new StateTableClass();
		tc03.nextState(0,0,false,op);
		assertEquals(2,op.getX());
		assertEquals(1,op.getY());
		assertEquals(0,op.getV1());
		assertEquals(0,op.getV2());
		
		
		StateTableClass tc04=new StateTableClass();
		tc04.nextState(0,1,true,op);
		assertEquals(2,op.getX());
		assertEquals(2,op.getY());
		assertEquals(1,op.getV1());
		assertEquals(0,op.getV2());
		
		StateTableClass tc05=new StateTableClass();
		tc05.nextState(0,1,false,op);
		assertEquals(2,op.getX());
		assertEquals(1,op.getY());
		assertEquals(0,op.getV1());
		assertEquals(1,op.getV2());
		
		StateTableClass tc06=new StateTableClass();
		tc06.nextState(1,0,true,op);
		assertEquals(3,op.getX());
		assertEquals(2,op.getY());
		assertEquals(1,op.getV1());
		assertEquals(1,op.getV2());
		
		StateTableClass tc07=new StateTableClass();
		tc07.nextState(1,0,false,op);
		assertEquals(3,op.getX());
		assertEquals(1,op.getY());
		assertEquals(1,op.getV1());
		assertEquals(0,op.getV2());
		
		StateTableClass tc08=new StateTableClass();
		tc08.nextState(1,1,true,op);
		assertEquals(3,op.getX());
		assertEquals(0,op.getY());
		assertEquals(0,op.getV1());
		assertEquals(1,op.getV2());
		
		StateTableClass tc09=new StateTableClass();
		tc09.nextState(1,1,false,op);
		assertEquals(4,op.getX());
		assertEquals(3,op.getY());
		assertEquals(1,op.getV1());
		assertEquals(1,op.getV2());
		
		
		
	}



}
