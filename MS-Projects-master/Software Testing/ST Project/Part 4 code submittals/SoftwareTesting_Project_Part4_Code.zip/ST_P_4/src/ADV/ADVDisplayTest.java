package ADV;

import static org.junit.Assert.*;

import org.junit.Test;

public class ADVDisplayTest {
	public static final String R = "R";
	public static final String D = "D";
	public static final String MP1 = "MP1";
	public static final String MP2 = "MP2";
	public static final String OFF = "Off";
	public static final int NO_OF_TC = 13;
	public static final int DELAY_TIME = 0;
	public static final boolean T = true;
	public static final boolean F =  false;
	
	public double vf[] = {100.005, 100.005, 99.990, 99.990, 25.005, 24.990, 14.985, 0.075, 0.075, 0.075, 0.075, 0.075, 99.990} ;
	public double vd[] = {-6.667, -6.667, -6.666, -6.666, -1.667, -1.666, -0.999, -0.005, -0.005, -0.005, -0.005, -0.005, -6.666};
	public double alt[] = {249.9, 249.9, 249.9, 49.9, 0.1, 23.8, 14.0, 0.0, 0.0, 0.0, 0.0, 0.0, 49.9};
	public int t_att[] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, 5, -1, 6, -1};
	public int d_att[] = {5, 5, 5, 5, 5, 5, 5, 5, 6, -1, 5, -1, 5};
	
	public double pwr_rem[] = {180, 180, 180, 180, 179, 172, 165, 155, 155, 155, 155, 155, 180} ;
	
	public String shd_pos[] = {R, R, R, R, D, D, D, R, R, R, R, R, D};
	public String shd_cmd[] = {R, R, R, R, D, D, R, R, R, R, R, R, D};
	public String shd_btn[] = {R, R, R, R, D, D, D, R, R, R, R, R, R};
	public String m_state[] = {MP1, MP1, MP1, MP2, MP2, MP2, MP2, OFF, OFF, OFF, OFF, OFF, MP2};
	
	public boolean alrt_pwr60[] = {F, F, F, F, T, T, T, T, T, T, T, T, F};
	public boolean alrt_pdmg[] = {F, T, F, F, F, F, F, F, F, T, T, T, F};
	public boolean alrt_pos[] = {T, T, F, F, F, F, F, F, F, F, F, F, F};
	public boolean alrt_dc[] = {F, F, F, F, F, F, F, F, T, F, F, T, F};
	public boolean alrt_pnd[] = {F, F, F, F, F, F, F, F, T, F, T, T, F};
	public boolean alrt_pd[] = {F, F, F, F, F, F, F, T, F, T, F, F, F};
	public boolean alrt_esr[] = {F, F, F, F, F, F, T, F, F, F, F, F, F};
	public boolean alrt_isrz[] = {F, F, F, F, F, T, F, F, F, F, F, F, F};
	
	
	
	@Test
	public void test() {
		Measurements measurements = new Measurements();
		Alerts alerts = new Alerts();
		
		
		ADVDisplay display = new ADVDisplay(measurements,alerts);
		display.setVisible(false);
		
		for (int tc_no = 0;  tc_no < NO_OF_TC ; tc_no++) {
			alerts = assignAlertInputs(alerts, tc_no);
			measurements = assignMeasurementInputs(measurements, tc_no);
			display = assignDisplayInputs(display, tc_no);
			display.updateDisplay(measurements, alerts);
			delay(DELAY_TIME);
		}
	}


	private Measurements assignMeasurementInputs(Measurements measure, int tc_no) {
		measure.setAltitude(alt[tc_no]);
		measure.setVd(vd[tc_no]);
		measure.setVf(vf[tc_no]);
		measure.setMotor_state(m_state[tc_no]);
		measure.setpower_remaining(pwr_rem[tc_no]);
		measure.setshield_position(shd_pos[tc_no]);
		measure.setshield_cmd(shd_cmd[tc_no]);
		measure.setTerr_attitude(t_att[tc_no]);
		measure.setCum_attitude(d_att[tc_no]);
		measure.setTestCaseNo(tc_no + 1);
		
		return measure;
	}

	private Alerts assignAlertInputs(Alerts alert, int tc_no) {
        alert.setPWR60(alrt_pwr60[tc_no]);
        alert.setPOS(alrt_pos[tc_no]);
        alert.setPDMG(alrt_pdmg[tc_no]);
        alert.setDC(alrt_dc[tc_no]);
        alert.setPND(alrt_pnd[tc_no]);
        alert.setESR(alrt_esr[tc_no]);
        alert.setISRZ(alrt_isrz[tc_no]);
        alert.setPD(alrt_pd[tc_no]);
        
        if(tc_no == (NO_OF_TC-1)) {
        	alert.setESR_latch(true);
        }
		return alert;
	}
	
	private ADVDisplay assignDisplayInputs(ADVDisplay display, int tc_no) {
		display.setShieldButton(shd_btn[tc_no]);
		return display;	
	}
	
	public void delay(int time) {
		try {
			Thread.sleep(time); // 1000 milliseconds is one second.
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}

}
