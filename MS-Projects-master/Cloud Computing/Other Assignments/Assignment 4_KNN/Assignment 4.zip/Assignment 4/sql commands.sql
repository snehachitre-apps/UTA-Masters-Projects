
create database newcitydb;
use newcitydb;
CREATE TABLE `LocationData` (
  `Country` varchar(30) DEFAULT NULL,
  `City` varchar(30) DEFAULT NULL,
  `AccentCity` varchar(30) DEFAULT NULL,
  `Region` varchar(10) DEFAULT NULL,
  `Population` bigint(20) DEFAULT NULL,
  `Latitude` double(16,7) DEFAULT NULL,
  `Longitude` double(16,7) DEFAULT NULL,
  KEY `myIndex` (`City`,`Latitude`,`Longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOAD DATA LOCAL INFILE 'C:/Users/Sneha/Downloads/worldcitiespop.csv' INTO TABLE LocationData FIELDS TERMINATED BY ',';

show index from LocationData;
drop index myIndex on LocationData;
alter table LocationData add index index1(AccentCity,Region,Latitude,Longitude);
alter table LocationData add index index2(Latitude,Longitude);
use newcitydb;
select * from LocationData


