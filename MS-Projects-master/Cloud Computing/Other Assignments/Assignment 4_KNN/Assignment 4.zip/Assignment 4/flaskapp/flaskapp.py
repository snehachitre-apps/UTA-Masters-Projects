#Name: Sneha S Chitre
#ID:  1001244953
#Lab number 4


from flask import Flask,render_template,request, redirect, url_for,session,flash
import requests
import boto3
from boto3.session import Session
import botocore
#import mysql.connector
import MySQLdb
import memcache
import itertools
import time
import os
urls=[]
url=""
memc = memcache.Client(['memcached.zbznia.cfg.usw2.cache.amazonaws.com:11211'], debug=0)
app = Flask(__name__)

#db = MySQLdb.connect("newcitydb.cth2q0syxqrb.us-west-2.rds.amazonaws.com","snehachitre","grayburst22","newcitydb")
db = MySQLdb.connect(host="newcitydb.cth2q0syxqrb.us-west-2.rds.amazonaws.com", port=3306,user="snehachitre", passwd="grayburst22",db="newcitydb")

cursor = db.cursor()
print "hi"
ncitylist=[]
kcitylist=[]
uname=""
password=""
valid=False
lines=""

def Authenticate(username,password):
    error = None
    valid = False
    print "1"
    logindetails = os.path.join(os.path.dirname(__file__), 'logindet.txt')
    with open(logindetails, 'r') as login:
        for entry in login:
            print "2"
            value = entry.split(',')
            if username.lower() == value[0].lower():
                if password.strip() == value[1].strip():
                    valid = True
                    break

    return valid


# @app.route("/knn")
# def knn():
#     print "knn main page"
#     return render_template("KNN.html")

@app.route('/')
def index():
    if 'username' in session:
        username_session = (session['username'])
        return render_template('Login.html', session_user_name=username_session)
    return render_template('Login.html')

@app.route("/login",methods=['GET','POST'])
def login():

    if request.method == 'POST':
        username=request.form['username']
        password=request.form['password']
        print username
        valid=Authenticate(username,password)

        print valid
        if valid==False:
            error = 'Invalid Credentials. Please try again.'
        else:
            uname=username
        return render_template("KNN.html",username=username)
    return render_template('Login.html', error=error)

@app.route("/decision",methods=['GET','POST'])
def decision():
    #print "1"

    #print "2"
    option=request.form['knn_options']
    #print "3"
    print option
    #print "4"
    if option=="K":
        #print "5"
         return render_template("KNN_K.html")
    else:
        if option=="N":
            #print "6"
            return render_template("KNN_N.html")
        else:
            return render_template("KNN.html")

    render_template("KNN.html")


@app.route("/n_given",methods=['GET','POST'])
def n_given():

    #print "1"
    cityname=request.form['cityname']
    nvalue=request.form['nvalue']
    rvalue=request.form['region']
    #Message=""
    cityregdist=cityname+rvalue+nvalue
    popularcities = memc.get(cityregdist)
    if not popularcities:
        t0=time.time()
        cursor.execute("SELECT Latitude,Longitude from LocationData where AccentCity=%s and Region=%s",(cityname,rvalue))
        data = cursor.fetchone()
        lat=data[0]
        long=data[1]
        cursor.execute("SELECT L.AccentCity,L.region,L.Latitude, L.Longitude,p.distance_unit * DEGREES(ACOS(COS(RADIANS(p.latpoint)) * COS(RADIANS(L.Latitude)) * COS(RADIANS(p.longpoint) - RADIANS(L.Longitude))+ SIN(RADIANS(p.latpoint)) * SIN(RADIANS(L.Latitude)))) AS distance_in_km FROM LocationData AS L JOIN (  SELECT  %s AS latpoint, %s AS longpoint ,%s AS radius, 111.045 AS distance_unit) AS p WHERE L.Latitude BETWEEN p.latpoint  - (p.radius / p.distance_unit) AND p.latpoint  + (p.radius / p.distance_unit) AND L.Longitude BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint)))) AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint)))) ORDER BY distance_in_km", (lat, long, nvalue))
        result=cursor.fetchall()
        for (AccentCity,region,Latitude,Longitude,distance_unit) in cursor:
            city=("{},{},{},{},{}".format(AccentCity,region,Latitude,Longitude,distance_unit))
            print city
            ncitylist.append(city)
        timetaken=time.time()-t0
    else:
        t0=time.time()
        print "Loaded data from memcached"
        popularcities=memc.get(cityregdist)
        print popularcities

        for row in popularcities:
            ncitylist.append(row)

            #print popcityk
        timetaken=time.time()-t0

    return render_template("KNN_N.html",list=ncitylist,time=timetaken)
    #return render_tempplate("KNN_N",list=ncitylist)

@app.route("/k_given",methods=['GET','POST'])
def k_given():
    #t1=time.time()
    CityName=request.form['CityName']
    kvalue=request.form['kvalue']
    regvalue=request.form['kregion']
    cityreg=CityName+regvalue
    popcitylist=[]
    popularcities = memc.get(cityreg)
    #print "pop city exists"
    print popularcities
    #popcitylist.append(CityName)

    #print regvalue
    kvalue=float(kvalue)
    if not popularcities:
        t1=time.time()
        cursor.execute("SELECT Latitude,Longitude from LocationData where AccentCity=%s and Region=%s",(CityName,regvalue))
        print "i am here"
        data = cursor.fetchone()
        lat=data[0]
        long=data[1]
        kcitylist=[]
        print lat,long
        nvalue=5
        #popcitylist.append(CityName)
        k=0
        while True:
            cursor.execute("SELECT L.AccentCity,L.region,L.Latitude, L.Longitude,p.distance_unit * DEGREES(ACOS(COS(RADIANS(p.latpoint)) * COS(RADIANS(L.Latitude)) * COS(RADIANS(p.longpoint) - RADIANS(L.Longitude))+ SIN(RADIANS(p.latpoint)) * SIN(RADIANS(L.Latitude)))) AS distance_in_km FROM LocationData AS L JOIN (  SELECT  %s AS latpoint, %s AS longpoint ,%s AS radius, 111.045 AS distance_unit) AS p WHERE L.Latitude BETWEEN p.latpoint  - (p.radius / p.distance_unit) AND p.latpoint  + (p.radius / p.distance_unit) AND L.Longitude BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint)))) AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint)))) ORDER BY distance_in_km", (lat, long, nvalue))

            result=cursor.fetchall()
            rows=cursor.rowcount
            print rows
            if rows > kvalue:

                cursor.execute("SELECT L.AccentCity,L.region,L.Latitude, L.Longitude,p.distance_unit * DEGREES(ACOS(COS(RADIANS(p.latpoint)) * COS(RADIANS(L.Latitude)) * COS(RADIANS(p.longpoint) - RADIANS(L.Longitude))+ SIN(RADIANS(p.latpoint)) * SIN(RADIANS(L.Latitude)))) AS distance_in_km FROM LocationData AS L JOIN (  SELECT  %s AS latpoint, %s AS longpoint ,%s AS radius, 111.045 AS distance_unit) AS p WHERE L.Latitude BETWEEN p.latpoint  - (p.radius / p.distance_unit) AND p.latpoint  + (p.radius / p.distance_unit) AND L.Longitude BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint)))) AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint)))) ORDER BY distance_in_km limit %s", (lat, long, nvalue,kvalue))
                result=cursor.fetchall()
                # for r in result:
                #     popcityk.append([])
                #     popcityk[k].append(result[0])
                #     popcityk[k].append(result[1])
                #     popcityk[k].append(result[2])
                #     popcityk[k].append(result[3])
                #     k=k+1
                # print popcityk
                #memc.set(AccentCity+regvalue,result)


                for (AccentCity,region,Latitude,Longitude,distance_unit) in cursor:
                    city="{},{},{},{},{}".format(AccentCity,region,Latitude,Longitude,distance_unit)


                    kcitylist.append(city)
                    print city
                memc.set(cityreg,kcitylist)
                print "Updated memcached with MySQL data"



                timetaken=time.time()-t1
                break

            else:
                nvalue=nvalue+1
    else:
        t1=time.time()
        print "Loaded data from memcached"
        popularcities=memc.get(cityreg)
        print popularcities

        for row in popularcities:
            kcitylist.append(row)

            #print popcityk
        timetaken=time.time()-t1

    return render_template("KNN_K.html",list=kcitylist,time=timetaken)


@app.route('/logout',methods=['GET','POST'])
def logout():
    #session.pop('username', None)
    return render_template("Login.html")

if __name__ == '__main__':
    app.run(debug=True)
    #app.run()