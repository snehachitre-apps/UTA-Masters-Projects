from flask import Flask,render_template,request, redirect, url_for,session,flash
import requests
import boto3
from boto3.session import Session
	


app = Flask(__name__)

session = Session(aws_access_key_id='AKIAJKTDCTCKEDVYDUAQ',aws_secret_access_key='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',region_name='us-west-2')

ec2 = session.resource('ec2')
ec2_us_west_2 = session.resource('ec2', region_name='us-west-2')

s3 = boto3.resource('s3')
s3.create_bucket(Bucket='snehachitrebucket2')
  
@app.route("/",methods=['GET','POST'])
def index():
    #return "image upload tool"
	if request.method == "POST":
		print 'abc'
    return render_template("ImageUploadTool.html")



if __name__ == '__main__':
   
    app.run(debug=True)
    #app.run()