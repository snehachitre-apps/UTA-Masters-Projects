
/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import scala.Tuple2;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.Optional;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.SparkSession;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;

public final class JavaWordCount {

	public static void main(String[] args) throws Exception {
		SparkConf sc = new SparkConf().setAppName("Sneha").setMaster("local");
		SparkSession spark = SparkSession.builder().appName("wdm06").config(sc)
				.config("spark.sql.warehouse.dir", "file:///C:/Users/Sneha/Desktop/WDM/SparkProject/").getOrCreate();

		JavaPairRDD<String, Integer> allData = null;
		int totalFiles = 0;
		// LOOP Each file and perform first map & reduce
		for (final File fileEntry : (new File("C:/Users/Sneha/Desktop/WDM/SparkProject/inputs")).listFiles()) {
			totalFiles++;
			// Mapper 1: Map with numbers
			JavaPairRDD<String, Integer> ones = Phase1.map(spark, fileEntry.getName().toLowerCase());

			// Reducer 1: Reduce it to collide number of occurance
			JavaPairRDD<String, Integer> counts = Phase1.reduce(ones);
			// Merge words with other files
			allData = Phase1.appendData(allData, counts);
		}
		// output first phase data
		allData.saveAsTextFile("output_map_red_1");
		// Mapper 2: Map filename as key and word&count as value
		JavaPairRDD<String, String> map2pair = Phase2.map(allData);
		// Reducer 2 part 1:Group all words into list based on file name and
		// append total words per file (N) to value
		JavaPairRDD<String, String> red2_final = Phase2.reduce(map2pair);
		// output second phase data
		red2_final.saveAsTextFile("output_map_red_2");

		// Mapper 3: Map word as key and filename&n&N&1 as value
		JavaPairRDD<String, String> map3pair = Phase3.map(red2_final);
		// Reducer 3 part 1:Group all filename&n&N&1 into list based on word and
		// modify list to filename&n&N&m
		JavaPairRDD<String, String> red3_final = Phase3.reduce(map3pair);

		// output third phase data
		red3_final.saveAsTextFile("output_map_red_3");

		final int D = totalFiles;
		System.out.println("totalFiles: "+totalFiles);
		// Mapper 4: Map word as key and filename&n&N&1 as value
		JavaPairRDD<String, Double> map4pair = Phase4.map(red3_final, D);
		// output forth phase mapper data
		map4pair.saveAsTextFile("output_map_4");
		spark.stop();
	}

	

	
	
}
