import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;

public class Phase2 {
	public static JavaPairRDD<String, String> map(JavaPairRDD<String, Integer> allData) {
		JavaPairRDD<String, String> map2pair = allData
				.mapToPair(new PairFunction<Tuple2<String, Integer>, String, String>() {

					@Override
					public Tuple2<String, String> call(Tuple2<String, Integer> p) throws Exception {
						String[] keys = p._1().split("&");
						return new Tuple2<String, String>(keys[1], keys[0] + "&" + p._2());
					}
				});
		return map2pair;
	}
	
	public static JavaPairRDD<String, String> reduce(JavaPairRDD<String, String> map2pair) {
		JavaPairRDD<String, List<String>> red2group = map2pair.groupByKey()
				.mapToPair(new PairFunction<Tuple2<String, Iterable<String>>, String, List<String>>() {
					@Override
					public Tuple2<String, List<String>> call(Tuple2<String, Iterable<String>> p) throws Exception {
						Iterator<String> it = p._2().iterator();
						List<String> values = new ArrayList<String>();
						int N = 0;
						while (it.hasNext()) {
							String[] keys = it.next().split("&");
							N += Integer.parseInt(keys[1]);
							values.add(keys[0] + "&" + keys[1]);
						}
						List<String> newValues = new ArrayList<String>();
						for (String v : values)
							newValues.add(v + "&" + N);
						return new Tuple2<String, List<String>>(p._1, newValues);
					}
				});
		// Reducer 2 part 2: ungroup and expand (word&filename, n&N)
		JavaPairRDD<String, String> red2_final = red2group
				.flatMapToPair(new PairFlatMapFunction<Tuple2<String, List<String>>, String, String>() {

					@Override
					public Iterator<Tuple2<String, String>> call(Tuple2<String, List<String>> p) throws Exception {
						List<Tuple2<String, String>> result = new ArrayList<>();
						for (String v : p._2) {
							String[] keys = v.split("&");
							result.add(new Tuple2<String, String>(keys[0] + "&" + p._1, keys[1] + "&" + keys[2]));
						}
						return result.iterator();
					}
				});
		return red2_final;
	}
}
