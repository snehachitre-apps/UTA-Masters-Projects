import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;

public class Phase3 {
	public static JavaPairRDD<String, String> map(JavaPairRDD<String, String> red2_final) {
		JavaPairRDD<String, String> map3pair = red2_final
				.mapToPair(new PairFunction<Tuple2<String, String>, String, String>() {

					@Override
					public Tuple2<String, String> call(Tuple2<String, String> p) throws Exception {
						String[] keys = p._1().split("&");
						return new Tuple2<String, String>(keys[0], keys[1] + "&" + p._2() + "&1");
					}
				});
		return map3pair;
	}
	public static JavaPairRDD<String, String> reduce(JavaPairRDD<String, String> map3pair) {
		JavaPairRDD<String, List<String>> red3group = map3pair.groupByKey()
				.mapToPair(new PairFunction<Tuple2<String, Iterable<String>>, String, List<String>>() {
					@Override
					public Tuple2<String, List<String>> call(Tuple2<String, Iterable<String>> p) throws Exception {
						Iterator<String> it = p._2().iterator();
						Set<String> values = new HashSet<String>();
						int m = 0;
						while (it.hasNext()) {
							String[] keys = it.next().split("&");
							values.add(keys[0] + "&" + keys[1] + "&" + keys[2]);
							m++;
						}
						List<String> newValues = new ArrayList<String>();
						for (String v : values)
							newValues.add(v + "&" + m);
						return new Tuple2<String, List<String>>(p._1, newValues);
					}
				});
		// Reducer 3 part 2: ungroup and expand (word&filename, n&N&m)
		JavaPairRDD<String, String> red3_final = red3group
				.flatMapToPair(new PairFlatMapFunction<Tuple2<String, List<String>>, String, String>() {

					@Override
					public Iterator<Tuple2<String, String>> call(Tuple2<String, List<String>> p) throws Exception {
						List<Tuple2<String, String>> result = new ArrayList<>();
						for (String v : p._2) {
							String[] keys = v.split("&");
							result.add(new Tuple2<String, String>(p._1 + "&" + keys[0],
									keys[1] + "&" + keys[2] + "&" + keys[3]));
						}
						return result.iterator();
					}
				});
		return red3_final;
	}
}
