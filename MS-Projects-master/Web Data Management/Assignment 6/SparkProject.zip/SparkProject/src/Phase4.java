import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;

public class Phase4 {
	public static JavaPairRDD<String, Double> map(JavaPairRDD<String, String> red3_final, final int D) {
		JavaPairRDD<String, Double> map4pair = red3_final
				.mapToPair(new PairFunction<Tuple2<String, String>, String, Double>() {

					@Override
					public Tuple2<String, Double> call(Tuple2<String, String> p) throws Exception {
						String[] keys = p._2().split("&");
						Double n = Double.parseDouble(keys[0]);
						Double N = Double.parseDouble(keys[1]);
						Double m = Double.parseDouble(keys[2]);
						Double TFIDF = (n/N) * Math.log10((D/m));
						return new Tuple2<String, Double>(p._1, TFIDF);
					}
				});
		return map4pair;
	}
}
