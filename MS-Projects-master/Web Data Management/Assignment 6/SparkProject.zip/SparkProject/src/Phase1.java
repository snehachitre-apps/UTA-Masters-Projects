import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.Optional;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.SparkSession;

import scala.Tuple2;

public class Phase1 {
	private static final Pattern SPACE = Pattern.compile(" ");
	public static List stopWords = Arrays.asList("a", "able", "about", "across", "after", "all", "almost", "also", "am",
			"among", "an", "and", "any", "are", "as", "at", "be", "because", "been", "but", "by", "can", "cannot",
			"could", "dear", "did", "do", "does", "either", "else", "ever", "every", "for", "from", "get", "got", "had",
			"has", "have", "he", "her", "hers", "him", "his", "how", "however", "i", "if", "in", "into", "is", "it",
			"its", "just", "least", "let", "like", "likely", "may", "me", "might", "most", "must", "my", "neither",
			"no", "nor", "not", "of", "off", "often", "on", "only", "or", "other", "our", "own", "rather", "said",
			"say", "says", "she", "should", "since", "so", "some", "than", "that", "the", "their", "them", "then",
			"there", "these", "they", "this", "tis", "to", "too", "twas", "us", "wants", "was", "we", "were", "what",
			"when", "where", "which", "while", "who", "whom", "why", "will", "with", "would", "yet", "you", "your");
	
	public static JavaPairRDD<String, Integer> map(SparkSession spark,final String fileName) {
		JavaRDD<String> lines = spark.read().textFile("inputs/" + fileName).javaRDD();
		// Seperate each words
		JavaRDD<String> words = lines.flatMap(new FlatMapFunction<String, String>() {
			@Override
			public Iterator<String> call(String s) {
				return Arrays.asList(SPACE.split(s)).iterator();
			}
		});
		// filter & remove stop words
		JavaRDD<String> nonStopWords = words.filter(new Function<String, Boolean>() {
			@Override
			public Boolean call(String s) throws Exception {
				return (!stopWords.contains(s.toLowerCase()));
			}
		});

		// Mapper 1: Map with numbers
		JavaPairRDD<String, Integer> ones = nonStopWords.mapToPair(new PairFunction<String, String, Integer>() {
			@Override
			public Tuple2<String, Integer> call(String s) {
				return new Tuple2<String, Integer>(s.toLowerCase() + "&" + fileName, 1);
			}
		});
		return ones;
	}
	
	public static JavaPairRDD<String, Integer> reduce(JavaPairRDD<String, Integer> ones) {
		return ones.reduceByKey(new Function2<Integer, Integer, Integer>() {
			@Override
			public Integer call(Integer i1, Integer i2) {
				return i1 + i2;
			}
		});
		
	}
	
	public static JavaPairRDD<String, Integer> appendData(JavaPairRDD<String, Integer> allData,
			JavaPairRDD<String, Integer> ones) {
		// Reducer 1: Reduce it to collide number of occurance
		JavaPairRDD<String, Integer> counts = Phase1.reduce(ones);
		// Merge words with other files
		if (allData != null) {
			JavaPairRDD<String, Tuple2<Optional<Integer>, Optional<Integer>>> lojRdd = allData
					.fullOuterJoin(counts);

			allData = lojRdd.mapToPair(
					new PairFunction<Tuple2<String, Tuple2<Optional<Integer>, Optional<Integer>>>, String, Integer>() {
						@Override
						public Tuple2<String, Integer> call(
								Tuple2<String, Tuple2<Optional<Integer>, Optional<Integer>>> t) throws Exception {
							int value1 = (t._2()._1().isPresent()) ? t._2()._1().get() : 0;
							int value2 = (t._2()._2().isPresent()) ? t._2()._2().get() : 0;
							return new Tuple2<String, Integer>(t._1, value1 + value2);
						}
					});
		} else
			allData = counts;
		return allData;
	}
}
